package r76117016.cnnyoutubechannelplayer10

import android.content.ClipDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.DividerItemDecoration
import r76117016.cnnyoutubechannelplayer10.databinding.ActivitySwipeRefreshBinding
import r76117016.cnnyoutubechannelplayer10.databinding.FragmentCnnListBinding

class cnnListFragment : Fragment(), CNNRecyclerViewAdapter.RecyclerViewClickListener {

    interface OnVideoSelectedListener {
        fun onVideoSelected(title: String, cover: Bitmap, url: String, description: String)
    }
    var listener: OnVideoSelectedListener? = null

    val adapter: CNNRecyclerViewAdapter by lazy {
        CNNRecyclerViewAdapter(listOf<VideoData>(),this)
    }

    val swipeRefreshLayout by lazy {
        binding.swipeRefreshLayout
    }

    private fun loadlist() {
        cnnXLMParser(object : ParserListener {
            override fun start() {
                swipeRefreshLayout.isRefreshing = true
            }

            override fun finish(videos: List<VideoData>) {
                adapter.videos = videos
                //  adapter.notifyDataSetChanged()
                swipeRefreshLayout.isRefreshing = false
            }

        }).parseURL(
            "https://www.youtube.com/feeds/videos.xml?channel_id=UCupvZG-5ko_eiXAupbDfxWw"
        )
    }
    lateinit var binding: FragmentCnnListBinding

    override fun onAttach(context: Context) {
        super.onAttach(context)
        listener = context as OnVideoSelectedListener
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCnnListBinding.inflate(inflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerView = binding.recylerView
        recyclerView.adapter = adapter
        recyclerView.addItemDecoration(
            DividerItemDecoration(
                recyclerView.context, DividerItemDecoration.VERTICAL
            )
        )
        swipeRefreshLayout.setOnRefreshListener {

            loadlist()
        }
        loadlist()
    }

    override fun onItemClick(view: View, position: Int) {
        val title = adapter.videos[position].title
        val cover = adapter.videos[position].cover
        val url = adapter.videos[position].url
        val description = adapter.videos[position].description

        listener?.onVideoSelected(title, cover!!, url, description)
    }
}