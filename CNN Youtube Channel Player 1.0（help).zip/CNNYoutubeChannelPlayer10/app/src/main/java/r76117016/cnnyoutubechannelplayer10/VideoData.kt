package r76117016.cnnyoutubechannelplayer10

import android.graphics.Bitmap
import java.net.URL

class VideoData (val title: String = "", val cover: Bitmap? = null, val url: String = "", val description: String = "") {
}