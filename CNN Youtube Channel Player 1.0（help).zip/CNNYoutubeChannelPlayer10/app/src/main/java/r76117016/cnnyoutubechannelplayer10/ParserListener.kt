package r76117016.cnnyoutubechannelplayer10

interface ParserListener {
    fun start()
    fun finish(videos: List<VideoData>)
}