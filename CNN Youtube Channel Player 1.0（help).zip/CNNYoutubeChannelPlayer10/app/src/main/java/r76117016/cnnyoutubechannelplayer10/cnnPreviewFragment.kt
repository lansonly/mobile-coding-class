package r76117016.cnnyoutubechannelplayer10

import android.graphics.Bitmap
import android.media.MediaPlayer
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.MediaController
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.databinding.ObservableField
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.android.youtube.player.YouTubeBaseActivity
import com.google.android.youtube.player.YouTubeInitializationResult
import com.google.android.youtube.player.YouTubePlayer
import r76117016.cnnyoutubechannelplayer10.databinding.ActivityPreviewBinding
import r76117016.cnnyoutubechannelplayer10.databinding.FragmentCnnPreviewBinding
import java.text.FieldPosition

class cnnPreviewFragment : Fragment(){
    private val title = ObservableField<String>()
    private val description = ObservableField<String>()
    private val cover = ObservableField <Bitmap>()
    private var url: String? = null
    private var isPlaying = false



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCnnPreviewBinding.inflate(inflater)
        return binding.root
    }
    val args: cnnPreviewFragmentArgs by navArgs<cnnPreviewFragmentArgs>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.title = title
        binding.cover = cover
        binding.description = description

        parentFragment?.let {
            if (savedInstanceState == null) previewVideo(args.title, args.cover, args.url, args.description)
        }
    }

    private lateinit var binding: FragmentCnnPreviewBinding

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("title", title.get())
        outState.putParcelable("cover", cover.get())
        outState.putString("url", url)
        outState.putString("description", description.get())
        outState.putBoolean("isPlaying", isPlaying)
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
        if (savedInstanceState != null) {
            title.set(savedInstanceState.getString("title"))
            cover.set(savedInstanceState.getParcelable("cover"))
            url = savedInstanceState.getString("url")
            description.set(savedInstanceState.getString("description"))
            isPlaying = savedInstanceState.getBoolean("isPlaying")
           // val position = savedInstanceState.getInt("currentPosition")
            previewVideo(title.get()!!, cover.get()!!, url!!,description.get()!!)
        }
    }




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    fun previewVideo(title: String, cover: Bitmap, url: String, description: String) {
        this.title.set(title)
        this.cover.set(cover)
        this.url = url
        this.description.set(description)
    }
}