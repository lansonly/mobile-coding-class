package r76117016.cnnyoutubechannelplayer10

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore.Audio.Media
import android.util.Log
import android.view.KeyEvent
import android.widget.*
import android.widget.MediaController.MediaPlayerControl
import androidx.databinding.DataBindingUtil
import androidx.databinding.ObservableField
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.android.youtube.player.YouTubeBaseActivity
import com.google.android.youtube.player.YouTubeInitializationResult
import com.google.android.youtube.player.YouTubePlayer
import com.google.android.youtube.player.YouTubePlayerView
import r76117016.cnnyoutubechannelplayer10.databinding.ActivityPreviewBinding

class PreviewActivity :  YouTubeBaseActivity(), MediaController.MediaPlayerControl {
    private val title = ObservableField<String>()
    private val description = ObservableField<String>()
    private val cover = ObservableField <Bitmap>()
    private var url: String? = null
    private var isPlaying = false
    private var bufferPercentage = 0
    private val YOUTUBE_API_KEY = "AIzaSyAwPso8BjOTdTikTJYcXExNzgO1gIPHVO8"
    private val mediaPlayer = MediaPlayer()
    private val mediaController: MediaController by lazy {
        object: MediaController(this) {
            override fun show(timeout: Int) {
                super.show(0)
            }

            override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
                if (event!!.keyCode == KeyEvent.KEYCODE_BACK) {
                    onBackPressed()
                }
                return super.dispatchKeyEvent(event)
            }
        }
    }

//    private val lifecycleObserver = object: DefaultLifecycleObserver {
//        override fun onCreate(owner: LifecycleOwner) {
//            super.onCreate(owner)
//           try {
//               mediaPlayer.setDataSource(url)
//              mediaPlayer.setOnPreparedListener {
//                  Log.i("MediaPlayer:", "I am ready...")
//                  mediaPlayer.setOnSeekCompleteListener {
//                       isPlaying = false
//                      mediaController.show()
//                    }
//                    mediaController.setAnchorView(binding.anchorView)
//                    mediaController.setMediaPlayer(owner as MediaPlayerControl)
//                    mediaController.show()
//                    if (position > 0) mediaPlayer.seekTo(position)
//                    if (isPlaying) mediaPlayer.start()
//                }
//                mediaPlayer.setOnBufferingUpdateListener { mediaPlayer, i ->
//                    bufferPercentage = i
//                }
//                mediaPlayer.prepareAsync()
//            } catch(e: Exception) {
//                e.printStackTrace()
//            }
//        }
//
//        override fun onStart(owner: LifecycleOwner) {
//            super.onStart(owner)
//        }
//
//        override fun onResume(owner: LifecycleOwner) {
//            super.onResume(owner)
//            if (isPlaying) mediaPlayer.start()
//        }
//
//        override fun onPause(owner: LifecycleOwner) {
//            super.onPause(owner)
//            if (isPlaying) mediaPlayer.pause()
//        }
//
//        override fun onStop(owner: LifecycleOwner) {
//            super.onStop(owner)
//        }
//
//        override fun onDestroy(owner: LifecycleOwner) {
////            super.onDestroy(owner)
////            mediaPlayer.release()
////            mediaController.hide()
//        }
//    }
//    init {
//        lifecycle.addObserver(lifecycleObserver)
//    }

    override fun onPause() {
            super.onPause()
            if (isPlaying) mediaPlayer.pause()
        }
    override fun onResume() {
            super.onResume()
            if (isPlaying) mediaPlayer.start()
        }

        override fun onDestroy() {
            super.onDestroy()
            mediaPlayer.release()
            mediaController.hide()
        }

            private lateinit var binding: ActivityPreviewBinding

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_preview)
                binding = DataBindingUtil.setContentView(this, R.layout.activity_preview)

                title.set(intent.getStringExtra("title"))
                cover.set(intent.getParcelableExtra<Bitmap>("cover"))
                description.set(intent.getStringExtra("description"))

                url = intent.getStringExtra("preview")


                //val textview = findViewById<TextView>(R.id.textView)
                // textview.text = title
                binding.title = title
                binding.description = description
                val playerView = binding.playerView
                //  val imageView = findViewById<ImageView>(R.id.imageView)
                //  imageView.setImageBitmap(cover)
                binding.cover = cover

                playerView.initialize(YOUTUBE_API_KEY, object : YouTubePlayer.OnInitializedListener {
                    override fun onInitializationSuccess(
                        p0: YouTubePlayer.Provider?,
                        p1: YouTubePlayer?,
                        p2: Boolean
                    ) {
                        p1?.loadVideo(url)
                        p1?.play()
                    }

                    override fun onInitializationFailure(
                        p0: YouTubePlayer.Provider?,
                        p1: YouTubeInitializationResult?
                    ) {
                        Toast.makeText(applicationContext,"Youtube init failed", Toast.LENGTH_LONG).show()
                    }


                })


                try {
                    mediaPlayer.setDataSource("https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview126/v4/58/c7/26/58c7268e-039e-17e8-9f25-38c2ed272d4d/mzaf_17568264072530070170.plus.aac.p.m4a")
                    mediaPlayer.setOnPreparedListener {
                        Log.i("MediaPlayer:", "I am ready...")
                        mediaPlayer.setOnSeekCompleteListener {
                            isPlaying = false
                            mediaController.show()
                        }
                        mediaController.setAnchorView(binding.anchorView)
                        mediaController.setMediaPlayer(this)
                        mediaController.show()

                        if (savedInstanceState != null) {
                            isPlaying = savedInstanceState.getBoolean("isPlaying")
                            val position = savedInstanceState.getInt("currentPosition")
                            mediaPlayer.seekTo(position)
                            if (isPlaying) {
                                mediaPlayer.start()
                            }
                            //  val button = findViewById<Button>(R.id.button)

                        }

                    }

                    mediaPlayer.setOnBufferingUpdateListener { mediaPlayer, i ->
                        bufferPercentage = i
                    }
                    mediaPlayer.prepareAsync()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }



    override fun start() {
        mediaPlayer.start()
        isPlaying = true
    }

    override fun pause() {
        mediaPlayer.pause()
        isPlaying = false
    }

    override fun getDuration(): Int {
        return mediaPlayer.duration
    }

    override fun getCurrentPosition(): Int {
        return mediaPlayer.currentPosition
    }

    override fun seekTo(p0: Int) {
        mediaPlayer.seekTo(p0)
    }

    override fun isPlaying(): Boolean {
        return isPlaying
    }

    override fun getBufferPercentage(): Int {
        return bufferPercentage
    }

    override fun canPause(): Boolean {
        return true
    }

    override fun canSeekBackward(): Boolean {
        return true
    }

    override fun canSeekForward(): Boolean {
        return true
    }

    override fun getAudioSessionId(): Int {
        return mediaPlayer.audioSessionId
    }
}