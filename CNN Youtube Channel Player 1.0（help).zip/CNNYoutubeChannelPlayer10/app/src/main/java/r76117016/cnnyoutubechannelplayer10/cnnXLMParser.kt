package r76117016.cnnyoutubechannelplayer10

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.URL

class cnnXLMParser(val listener: ParserListener) {
    private val factory = XmlPullParserFactory.newInstance()
    private val parser = factory.newPullParser()
    private val data = mutableListOf<VideoData>()
    private var videoTitle = ""
    private var text = ""
    private var Imagefound = false
    private var videoCover: Bitmap? = null
    private var videoURL: String = ""
    private var videoID: String = ""
    private var videoDesc = ""


    fun parseURL(url: String) {
        listener.start()
        GlobalScope.launch {

            try {
                val inputStream = URL(url).openStream()
                parser.setInput(inputStream, null)
                var eventType = parser.next()

                while(eventType != XmlPullParser.END_DOCUMENT){
                    var tagName = parser.name
                    if (tagName.equals("entry", ignoreCase = true) && eventType == XmlPullParser.START_TAG){
                        while (!(tagName.equals("entry",ignoreCase = true) && eventType == XmlPullParser.END_TAG)) {
                            when(eventType) {
                                XmlPullParser.START_TAG -> if (tagName.equals("media:thumbnail", ignoreCase = true)) {
                                    Imagefound = parser.getAttributeValue(null,"height").equals("360")
                                } else if (tagName.equals("media:content", ignoreCase = true)) {
                                    if (parser.getAttributeValue(null, "type").equals("application/x-shockwave-flash")) {
                                     videoURL = parser.getAttributeValue(null, "url")
                                    }
                                }
                                XmlPullParser.TEXT -> text = parser.text
                                XmlPullParser.END_TAG -> if (tagName.equals("media:title",ignoreCase = true)) {
                                    videoTitle = text
                                }
                                    else if (tagName.equals("media:thumbnail", ignoreCase = true) && Imagefound) {
                                    val url = parser.getAttributeValue(null, "url")
                                    Log.i("picture",url)
                                    val inputStream = URL(url).openStream()
                                    videoCover = Bitmap.createScaledBitmap(BitmapFactory.decodeStream(inputStream),150, 150, false);
                                    Imagefound = false
                                }else if (tagName.equals("media:description",ignoreCase = true)) {
                                    videoDesc = text
                                }else if (tagName.equals("yt:videoId", ignoreCase = true)) {
                                    videoID = text
                                }

                            }
                            eventType = parser.next()
                            tagName = parser.name
                        }
                        data.add(VideoData(videoTitle,videoCover, videoID,videoDesc))
                        Log.i("title", videoTitle)
                        Log.i("description", videoDesc)
                        Log.i("URL",videoURL)
                        Log.i("ID",videoID)
                        Imagefound = false
                    }
                    eventType = parser.next()
                }

                withContext(Dispatchers.Main) {
                    listener.finish(data)
                }
            } catch(e: Throwable) {
                e.printStackTrace()
            }
        }

    }
}