package r76117016.cnnyoutubechannelplayer10

import android.app.ListActivity
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.navigation.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.youtube.player.YouTubeInitializationResult
import com.google.android.youtube.player.YouTubePlayer
import com.google.android.youtube.player.YouTubePlayerFragment
import com.google.android.youtube.player.YouTubePlayerView
import r76117016.cnnyoutubechannelplayer10.databinding.ActivityPreviewBinding


class MainActivity : AppCompatActivity(), cnnListFragment.OnVideoSelectedListener{
    private var url: String? = null
    private var isPlaying = false
    private var currentPosition : Int = 0
    private val YOUTUBE_API_KEY = "AIzaSyAwPso8BjOTdTikTJYcXExNzgO1gIPHVO8"
    private lateinit var binding: ActivityPreviewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = DataBindingUtil.setContentView(this, R.layout.fragment_cnn_preview)
        url = intent.getStringExtra("preview")
        val playerFragment = fragmentManager.findFragmentById(R.id.playerView) as YouTubePlayerFragment?
        playerFragment?.initialize(YOUTUBE_API_KEY, object : YouTubePlayer.OnInitializedListener{

            override fun onInitializationSuccess(provider: YouTubePlayer.Provider?,
                                                 player: YouTubePlayer?,
                                                 wasRestored: Boolean
            ) {
                if (!wasRestored) {
                    player?.cueVideo(url)

                    player?.setPlayerStateChangeListener(object : YouTubePlayer.PlayerStateChangeListener {
                        override fun onLoading() {
                        }

                        override fun onLoaded(videoId: String?) {
                            url
                        }

                        override fun onAdStarted() {
                        }

                        override fun onVideoStarted() {
                            isPlaying = true
                        }

                        override fun onVideoEnded() {
                            isPlaying = false
                        }

                        override fun onError(errorReason: YouTubePlayer.ErrorReason?) {
                        }
                    })

                    if (isPlaying && (player != null)) {
                        currentPosition = player.currentTimeMillis
                    }

                }
            }

            override fun onInitializationFailure(provider: YouTubePlayer.Provider,
                                                 errorReason: YouTubeInitializationResult
            ) {
                Toast.makeText(applicationContext,"Init Failed", Toast.LENGTH_LONG ).show()
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        outState.putBoolean("isPlaying",isPlaying)
    }

    override fun onVideoSelected(title: String, cover: Bitmap, url: String, description: String) {
        val previewFragment = supportFragmentManager.findFragmentById(R.id.previewFragment) as cnnPreviewFragment?
        if (previewFragment != null) {
            previewFragment?.previewVideo(title, cover, url, description)
        } else {
            val action = cnnListFragmentDirections.actionCnnListFragmentToCnnPreviewFragment(
                title, cover, url, description)
            findNavController(R.id.navHostFragment)?.navigate(action)
        }
    }

}
